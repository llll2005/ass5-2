#ifndef ENVIROMENT_H
#define ENVIROMENT_H

// enviroment variables
// don't change these values

const int GAME_WINDOW_SIZE_X = 35;
const int GAME_WINDOW_SIZE_Y = 20;

const int GAME_WINDOW_ONEBLOCK_WIDTH = 2;

const double SPEED = 0.1;

#endif