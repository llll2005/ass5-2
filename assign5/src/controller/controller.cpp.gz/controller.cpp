#include <iostream>

#include "controller.h"
#include "../gameobjects/room/roomdata.h"
#include "../functions/position/position.h"
#include "../functions/AnsiPrint/AnsiPrint.h"
#include "../gameobjects/room/room.h"
#include "enviroment.h"

Controller::Controller() {
    const int defaultRoomIndex = 0;
    RoomData roomData = ROOM_DATA[defaultRoomIndex];
    Room *roomPtr = new Room(roomData); // Create a pointer to Room object
    rooms[defaultRoomIndex] = roomPtr;
   // for( int i = 0; i <= GAME_WINDOW_SIZE_Y; i++){
   //      for(int j = 0; j <= GAME_WINDOW_SIZE_X; j++){
   //          roomData.defaultRoomObjectMap[i][j] = ROOM_DATA[defaultRoomIndex].defaultRoomObjectMap[i][j];
   //      }
   // } 

}

// Add your code to implement the Controller class here.

Controller::
~Controller(){}


RunningState Controller::
run(InputState action){
    // render();
    // Room rm;
    // cout << rm.defaultRoomObjectMap[2][2] << endl;
    if( action == GameState::ACTION_EXIT ) return EXIT;
    Position tmpPosition = player->getPosition();
    switch (action) {
        case GameState::ACTION_UP:
            if( rooms[0]->walkable(Position(tmpPosition.getX(), tmpPosition.getY()-1)) ) 
                player->setPosition(Position(tmpPosition.getX(), tmpPosition.getY()-1));
            break;
        case GameState::ACTION_DOWN:
            if( rooms[0]->walkable(Position(tmpPosition.getX(), tmpPosition.getY()+1)) ) 
                player->setPosition(Position(tmpPosition.getX(), tmpPosition.getY()+1));
            break;
        case GameState::ACTION_LEFT:
            if( rooms[0]->walkable(Position(tmpPosition.getX()-1, tmpPosition.getY())) ) 
                player->setPosition(Position(tmpPosition.getX()-1, tmpPosition.getY()));
            break;
        case GameState::ACTION_RIGHT:
            if( rooms[0]->walkable(Position(tmpPosition.getX()+1, tmpPosition.getY())) ) 
                player->setPosition(Position(tmpPosition.getX()+1, tmpPosition.getY()));
            break;
        default: break;
    }

    // for (int i = 0; i < GAME_WINDOW_SIZE_Y; i++) {
    //     for (int j = 0; j < GAME_WINDOW_SIZE_X; j++) {
    //         std::cout << (int)rooms[0]->defaultRoomObjectMap[i][j] << " ";
    //     }
    //     std::cout << std::endl;
    // }
    render();
    return GameState::PLAY;
}


// render
void Controller::render() {
    switch (state) {
    case PROCESS_MOVEMENT:{
        for (int y = 0; y < GAME_WINDOW_SIZE_Y; y++) {
            for (int x = 0; x < GAME_WINDOW_SIZE_X; x++) {
                if(player->getPosition() == Position(x, y)) {
                    player->render();
                    continue;
                }
                rooms[currentRoomIndex]->render(Position(x, y));
            }
            AnsiPrint("\n", nochange, nochange);
        }
        break;
    }
    default:
        break;
    }
    output();
}
