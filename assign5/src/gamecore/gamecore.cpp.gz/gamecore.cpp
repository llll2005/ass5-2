#include "gamecore.h"
#include "gamestate.h"
#include "../controller/controller.h"
#include <iostream>

GameCore::GameCore() {
}

GameCore::~GameCore() {
    
}

RunningState GameCore::lifeCycle(InputState action) {
    return gameController.run(action);
}

InputState GameCore::ConvertInputToAction(int input) {
    switch (input) {
        case 'w':
        case 'W':
            return ACTION_UP;//1
        case 's':
        case 'S':
            return ACTION_DOWN;//2
        case 'a':
        case 'A':
            return ACTION_LEFT;//3
        case 'd':
        case 'D':
            return ACTION_RIGHT;//4

        case 32: // space
            return ACTION_CONFIRN;//5
        case 10: // enter
            return ACTION_CONFIRN;//5

        case 27: // esc
            return ACTION_PAUSE;//6

        case -1:
            return ACTION_INIT;//8

        default:
            return ACTION_NONE;//0
    }
}
