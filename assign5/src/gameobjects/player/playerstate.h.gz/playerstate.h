#ifndef PLAYERSTATE_H
#define PLAYERSTATE_H

namespace PlayerState
{
    enum MoveState {
        MOVE,
        // LEFTROOM,
        // RIGHTROOM,
    };
} // namespace PlayerState


#endif