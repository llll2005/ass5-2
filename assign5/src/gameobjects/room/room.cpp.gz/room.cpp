#include "room.h"
#include "roomdata.h"
#include "../../functions/AnsiPrint/AnsiPrint.h"
#include "../../functions/position/position.h"
#include "roomstate.h"
#include <string>
#include <iostream>

// read data to the Room class
Room::
Room(RoomData data) {

    roomID = data.id;
    roomName = data.name;
    roomDescription = data.description;
    playerInitialPosition = data.playerInitialPosition;
    for (int i = 0; i < GAME_WINDOW_SIZE_Y; i++) {
        for (int j = 0; j < GAME_WINDOW_SIZE_X; j++) {
            defaultRoomObjectMap[i][j] = static_cast<RoomObject>(data.defaultRoomObjectMap[i][j]);
            // defaultRoomObjectMap[i][j] = static_cast<RoomObject>(defaultRoomObjectMap[i][j]);
            // std::cout << defaultRoomObjectMap[i][j] ;
        }
        // std::cout<< std::endl;
    }
}

// add your code to implement the Room class here

bool Room::
walkable(Position newPosition){ 
    return ( 
        newPosition.getX() >= 0 &&
        newPosition.getY() >= 0 &&
        newPosition.getX() <= GAME_WINDOW_SIZE_X&&
        newPosition.getY() <= GAME_WINDOW_SIZE_Y&&
        this->defaultRoomObjectMap[newPosition.getY()][newPosition.getX()] != RoomState::OBJECT_WALL &&
        this->defaultRoomObjectMap[newPosition.getY()][newPosition.getX()] != RoomState::OBJECT_ROCK &&
        this->defaultRoomObjectMap[newPosition.getY()][newPosition.getX()] != RoomState::OBJECT_GRASS
        );
} 

// render
void Room::
render(Position position) {
    switch(this->defaultRoomObjectMap[position.getY()][position.getX()]) {
        case OBJECT_NONE:
            AnsiPrint("  ", black, black);
            break;
        case OBJECT_DOOR:
            AnsiPrint("DR", yellow, black);
            break;
        case OBJECT_WALL:
            AnsiPrint("██", white, black);
            break;
        case OBJECT_GRASS:
            AnsiPrint("WW", green, black);
            break;
        case OBJECT_ROCK:
            AnsiPrint("▲▲", yellow, black);
            break;
        case OBJECT_WATER:
            if(rand() % 2 == 0) {
                AnsiPrint("~~", cyan, blue);
            } else {
                AnsiPrint("……", cyan, blue);
            }
            break;
    }
}

int Room::
getID(){ return roomID; }

std::string Room::
getName(){ return roomName; }

Position Room::
getIP(){ return playerInitialPosition; }

Room::
~Room(){}
