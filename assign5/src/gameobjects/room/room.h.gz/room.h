#ifndef ROOM_H
#define ROOM_H

#include <string>
#include <vector>

#include "../../controller/enviroment.h"
#include "../../functions/position/position.h"
#include "roomstate.h"

using namespace RoomState;

class Room {
    private:
        int roomID;
        std::string roomName;
        std::string roomDescription;

        Position playerInitialPosition;


    public:
        RoomObject defaultRoomObjectMap[GAME_WINDOW_SIZE_Y][GAME_WINDOW_SIZE_X];
        Room(RoomData roomData);
        ~Room();

        bool walkable(Position position);

        void render(Position position);

        int getID();

        std::string getName();

        Position getIP();
};

#endif
