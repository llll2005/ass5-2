#include "position.h"
// #include "../../controller/enviroment.h"

// Add your code to implement the Position class here.
Position::Position(int iX, int iY) {
  positionX = iX;
  positionY = iY;
}
Position::
Position(){}

Position::
~Position(){}

int Position::
getX(){ return positionX; }

int Position::
getY(){ return positionY; }

bool Position::
operator==(const Position &other) const { return positionX == other.positionX && positionY == other.positionY; }
