#ifndef GAMEPROCESSSTATE_H
#define GAMEPROCESSSTATE_H

namespace GameProcess
{
    enum GameProcessState {
        PROCESS_MOVEMENT,
        // PROCESS_BATTLE,
        // PROCESS_GAMEOVER,
        // PROCESS_CLEAR,
        // PROCESS_EXIT
    };
} // namespace GameProcess


#endif